// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

#ifndef OVR_ORGSCOPEDID_H
#define OVR_ORGSCOPEDID_H

#include "OVR_Platform_Defs.h"
#include "OVR_Types.h"
#include <stddef.h>

typedef struct ovrOrgScopedID *ovrOrgScopedIDHandle;

OVRP_PUBLIC_FUNCTION(ovrID) ovr_OrgScopedID_GetID(const ovrOrgScopedIDHandle obj);

#endif
